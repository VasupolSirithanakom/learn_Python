import clear

if __name__ == '__main__':
    clear.clear()
